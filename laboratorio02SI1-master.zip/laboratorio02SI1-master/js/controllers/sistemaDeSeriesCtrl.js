function openTab(evt, tabName) {
	var i, tabcontent, tablinks;
	tabcontent = document.getElementsByClassName("tabcontent");
	for (i = 0; i < tabcontent.length; i++) {
		tabcontent[i].style.display = "none";
	}
	tablinks = document.getElementsByClassName("tablinks");
	for (i = 0; i < tablinks.length; i++) {
		tablinks[i].className = tablinks[i].className.replace(" active", "");
	}
	document.getElementById(tabName).style.display = "block";
	evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();

angular.module("sistemaDeSeries").controller("sistemaDeSeriesCtrl", function ($scope, $http, $mdDialog) {
	$scope.app = "Sistema de Séries";
	$scope.series = [];
	$scope.perfil = [];
	$scope.watchList = [];
	$scope.episodios = [];
	$scope.notas = [];
	$scope.dialogSerie = {};

	$scope.pesquisarSerie = function(serie) {
		$http.get("https://omdbapi.com/?s="+ serie +"&apikey=93330d3c&type=series").then(function (response) {

			if (response.data.Response === "False") {
				alert("A série não pode ser encontrada");
			} else {
				$scope.series = response.data.Search;
			}
		});
	}

	$scope.adicionarAWatchlist = function(serie) {

		if($scope.verificaSeJaExisteNoArray(serie, $scope.perfil)) {
			alert("Essa série já foi cadastrada no seu perfil");
		} else {
			if ($scope.verificaSeJaExisteNoArray(serie, $scope.watchList)) {
				alert("Essa série já foi cadastrada na sua watchlist");
			} else {
				$scope.watchList.push(serie);
			}
		}

	}

	$scope.adicionarAoMeuPerfil = function(serie) {

		if($scope.verificaSeJaExisteNoArray(serie, $scope.perfil) || $scope.verificaSeJaExisteNoArray(serie, $scope.watchList)) {
			alert("Essa série já foi cadastrada");
		} else {
			$scope.perfil.push(serie);
		}
	}	

	$scope.removeSerie = function(serie, list) {
		var indexDaSerieASerRemovida = list.indexOf(serie);
		<!--verificando se o array nao é vazio-->
		if (indexDaSerieASerRemovida > -1) {
			decisao = confirm("Você deseja realmente apagar essa série do seu perfil?");
			if (decisao){
				list.splice(indexDaSerieASerRemovida, 1);
			}

		}
	}

	$scope.adicionaAoPerfilERemoveDaWatchlist = function(serie, list) {

		if($scope.verificaSeJaExisteNoArray(serie, $scope.perfil)) {
			alert("Essa série já foi cadastrada");
		} else {
			$scope.perfil.push(serie);
		}

		var indexDaSerieASerRemovida = list.indexOf(serie);
		<!--verificando se o array nao é vazio-->
		if (indexDaSerieASerRemovida > -1) {
			decisao = confirm("Você deseja realmente adicionar essa série ao seu perfil?");
			if (decisao){
				list.splice(indexDaSerieASerRemovida, 1);
			}

		}

	}


	$scope.verificaSeJaExisteNoArray = function(serie, list) {
		return (list.indexOf(serie) != -1);
	}

	$scope.verInfo = function (ev, serie) {
		$http.get("https://omdbapi.com/?i="+ serie.imdbID +"&apikey=93330d3c&type=series").then(function (response) {
			$scope.serieDialog = response.data;
			
			$mdDialog.show({
				controller: DialogController,
				templateUrl: 'info.html',
				parent: angular.element(document.body),
				targetEvent: ev,
				clickOutsideToClose:true,
				locals: {
					serieDialog: $scope.serieDialog
				}
			});
		});

	}

	$scope.registraNotas = function(serie, nota) {
		var indexSerie = $scope.perfil.indexOf(serie);

		if (indexSerie > -1) {
			$scope.notas[indexSerie] =  nota;
			alert("Nota da série cadastrada");
		}

	}

	$scope.registraUltimoEps = function(serie, eps) {
		var indexSerie = $scope.perfil.indexOf(serie);

		if (indexSerie >  -1) {
			$scope.episodios[indexSerie] = eps;
			alert("Último episódio da série cadastrado");
		}
	}

	function DialogController($scope, $mdDialog, serieDialog) {
		$scope.serie = serieDialog;

		$scope.hide = function() {
			$mdDialog.hide();
		};

		$scope.cancel = function() {
			$mdDialog.cancel();
		};

		$scope.answer = function(answer) {
			$mdDialog.hide(answer);
		};
	}
});

