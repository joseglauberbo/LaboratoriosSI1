package com.example.lab03.objectServices;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.lab03.object.Series;
import com.example.lab03.objectRepository.SeriesRepository;

@Service
public class SeriesService {
	
	@Autowired
	SeriesRepository seriesRepository;

	public Series adicionaSerie(Series serie) {
		return seriesRepository.save(serie);
	}
	
	public Series excluirSerie(Integer serieID) {
		Series serie = pegarSerie(serieID);
		seriesRepository.delete(serie);
		return serie;
	}
	
	public Series atualizaSerie(Series serie) {
		return seriesRepository.save(serie);
	}
	
	public Series pegarSerie(Integer serieID) {
		return seriesRepository.findOne(serieID);
	}
	

	public List<Series> pegarSeries() {
		return seriesRepository.findAll();
	}
	
}
