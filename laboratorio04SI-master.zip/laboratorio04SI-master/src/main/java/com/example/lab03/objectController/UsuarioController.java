package com.example.lab03.objectController;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.lab03.object.Usuario;
import com.example.lab03.objectServices.UserService;

@RestController
@RequestMapping("/usuario")
public class UsuarioController {
	
	@Autowired
	private UserService usuarioService;
	
	@RequestMapping(method = RequestMethod.POST, value = "/")
	public ResponseEntity<Usuario> cadastrar(@RequestBody Usuario usuario) {
		Usuario usuarioCadastrado = usuarioService.cadastrar(usuario);
		
		if (usuarioCadastrado == null) {
			return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
		}
		return new ResponseEntity<>(usuarioCadastrado, HttpStatus.CREATED);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/login")
	public ResponseEntity logar(@RequestBody Usuario usuario) {
		Usuario usuarioLogado = usuarioService.logar(usuario);
		if (usuarioLogado == null) {
			return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
		}
		
		return new ResponseEntity<>(usuarioLogado, HttpStatus.OK);
	}
}
