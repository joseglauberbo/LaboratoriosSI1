function openTab(evt, tabName) {
	var i, tabcontent, tablinks;
	tabcontent = document.getElementsByClassName("tabcontent");
	for (i = 0; i < tabcontent.length; i++) {
		tabcontent[i].style.display = "none";
	}
	tablinks = document.getElementsByClassName("tablinks");
	for (i = 0; i < tablinks.length; i++) {
		tablinks[i].className = tablinks[i].className.replace(" active", "");
	}
	document.getElementById(tabName).style.display = "block";
	evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();

angular.module("sistemaDeSeries").controller("sistemaDeSeriesCtrl", function ($scope, $http, $mdDialog) {
	$scope.app = "Sistema de Séries";
	$scope.series = [];
	$scope.perfil = [];
	$scope.watchList = [];
	$scope.episodios = [];
	$scope.notas = [];
	$scope.dialogSerie = {};
	$scope.logado = false;
	$scope.usuario;


	$scope.cadastrar = function() {
		var nomeCadastro = prompt("Name:", "Glauber Braz")
		var emailCadastro = prompt("Email:", "email@email.com");
		var senhaCadastro = prompt("Password:", "***********");
		var usuarioCadastrado = {"name": nomeCadastro, "email": emailCadastro, "password": senhaCadastro};
		var link = $http.post("/usuario/", usuarioCadastrado).then(function(response) {
			if (response.data === "") {
				alert("Email já cadastrado");
			} else {
				$scope.usuario = response.data;
				$scope.logado = true;
			}
		})
	};

	$scope.logar = function() {
		var emailLogin = prompt("Email:", "email@email.com");
		var senhaLogin = prompt("Password:", "***********");
		var usuarioLogin = {name: "", email: emailLogin, password: senhaLogin};
		var link = $http.post("/usuario/login/", usuarioLogin).then(function(response) {
			$scope.usuario = response.data;
			$scope.logado = true;
			$scope.carregarSeries();
		})
	};

	$scope.deslogar = function() {
		if (confirm("Tem certeza que deseja deslogar?")) {
			$scope.usuario = undefined;
			$scope.watchlist = [];
			$scope.perfil = [];
			$scope.series = [];
			$scope.logado = false;
		}
	};

	$scope.carregarSeries = function () {
		console.log($scope.usuario.id);
		var link = $http.get("/usuario/" + $scope.usuario.id + "/series/").then(function (response) {
			$scope.series = response.data;
			$scope.carregarPerfilEWatchList();
		})
	};

	$scope.carregarPerfilEWatchList = function() {
		for (var i = 0; i < $scope.series.length; i++) {
			if($scope.series[i].noPerfil === true) {
				$scope.carregarPerfil($scope.series[i]);
			} else {
				$scope.carregarWatchlist($scope.series[i].imdbID);
			}
		}
	};

	$scope.carregarPerfil = function(serie) {
		var link = $http.get("https://omdbapi.com/?i=" + serie.imdbID + "&plot=full&apikey=93330d3c").then(function(response) {
			serieCarregada = response.data;
			serieCarregada.avaliacao = serie.avaliacao;
			serieCarregada.ultimoEpisodio = serie.ultimoEpisodio;
			$scope.perfil.push(serieCarregada);
		})
	};

	$scope.carregarWatchlist = function(imdbID) {
		var link = $http.get("https://omdbapi.com/?i=" + imdbID + "&plot=full&apikey=93330d3c").then(function(response) {
			serieCarregada = response.data;
			$scope.watchlist.push(serieCarregada);
		})
	};

	$scope.pesquisarSerie = function(serie) {
		$http.get("https://omdbapi.com/?s="+ serie +"&apikey=93330d3c&type=series").then(function (response) {

			if (response.data.Response === "False") {
				alert("A série não pode ser encontrada");
			} else {
				$scope.series = response.data.Search;
			}
		})
	};

	$scope.addBD = function (serie, noPerfil) {
		var serieAddPerfil = {"imdbID": serie.imdbID, "avaliacao": "N/A", "ultimoEpisodio": "N/A", "usuarioID": $scope.usuario.id, "noPerfil": noPerfil};
		var link = $http.post("/serie/", serieAddPerfil).then(function(response) {
			$scope.series.push(response.data);
		})
	};

	$scope.removeBD = function(id) {
		var link = $http.delete("/serie/" + id).then(function(response) {
			return response.data;
		})
	};

	$scope.adicionarAWatchlist = function(serie) {

		if($scope.logado === false) {
			alert("Faça login primeiro");
			return;
		}

		if($scope.verificaSeJaExisteNoArray(serie, $scope.perfil)) {
			alert("Essa série já foi cadastrada no seu perfil");
		} else {
			if ($scope.verificaSeJaExisteNoArray(serie, $scope.watchList)) {
				alert("Essa série já foi cadastrada na sua watchlist");
			} else {
				$scope.watchList.push(serie);
				$scope.addBD(serie, false);
			}
		}
	};

	$scope.contains = function (array, serie) {
    for (var i = 0; i < array.length; i++) {
      if(array[i].imdbID === serie.imdbID) {
        return true;
      }
    }
    return false;
  	};

	$scope.adicionarAoMeuPerfil = function(serie) {

		if($scope.logado === false) {
			alert("Faça login primeiro");
			return;
		}

		if($scope.verificaSeJaExisteNoArray(serie, $scope.perfil) || $scope.verificaSeJaExisteNoArray(serie, $scope.watchList)) {
			alert("Essa série já foi cadastrada");
		} else {
			var link = $http.get("https://omdbapi.com/?i=" + serie.imdbID + "&plot=full&apikey=93330d3c").then(function(response) {
			serie = response.data;
        	serie.avaliacao = "N/A"
        	serie.ultimoEpisodio = "N/A"
			$scope.perfil.push(serie);
			$scope.addBD(serie, true);
		})
		}
	};	

	$scope.removeSerie = function(serie, list) {
		var indexDaSerieASerRemovida = list.indexOf(serie);
		<!--verificando se o array nao é vazio-->
		if (indexDaSerieASerRemovida > -1) {
			decisao = confirm("Você deseja realmente apagar essa série do seu perfil?");
			if (decisao){
				list.splice(indexDaSerieASerRemovida, 1);
				var id = $scope.getIdByImdbID(serie);
				$scope.removeBD(id);
			}
		}
	};

	$scope.adicionaAoPerfilERemoveDaWatchlist = function(serie, list) {

		if($scope.verificaSeJaExisteNoArray(serie, $scope.perfil)) {
			alert("Essa série já foi cadastrada");
		} else {
			$scope.perfil.push(serie);
		}

		var indexDaSerieASerRemovida = list.indexOf(serie);
		<!--verificando se o array nao é vazio-->
		if (indexDaSerieASerRemovida > -1) {
			decisao = confirm("Você deseja realmente adicionar essa série ao seu perfil?");
			if (decisao){
				list.splice(indexDaSerieASerRemovida, 1);
				var id = $scope.getIdByImdbID(serie);
				$scope.removeBD(id);
			}
		}
	};

	$scope.getIdByImdbID = function(serie) {
		for(var i = 0; i < $scope.series.length; i++) {
			if ($scope.series[i].imdbID === serie.imdbID) {
				return $scope.series[i].id;
			}
		}
	};

	$scope.verificaSeJaExisteNoArray = function(serie, list) {
		return (list.indexOf(serie) != -1);
	};

	$scope.verInfo = function (ev, serie) {
		$http.get("https://omdbapi.com/?i="+ serie.imdbID +"&apikey=93330d3c&type=series").then(function (response) {
			$scope.serieDialog = response.data;

			$mdDialog.show({
				controller: DialogController,
				templateUrl: 'info.html',
				parent: angular.element(document.body),
				targetEvent: ev,
				clickOutsideToClose:true,
				locals: {
					serieDialog: $scope.serieDialog
				}
			})
		})
	};

	$scope.registraNotas = function(serie, nota) {
		var indexSerie = $scope.perfil.indexOf(serie);

		if (indexSerie > -1) {
			$scope.notas[indexSerie] =  nota;
			alert("Nota da série cadastrada");
		}
	};

	$scope.registraUltimoEps = function(serie, eps) {
		var indexSerie = $scope.perfil.indexOf(serie);

		if (indexSerie >  -1) {
			$scope.episodios[indexSerie] = eps;
			alert("Último episódio da série cadastrado");
		}
	};

	function DialogController($scope, $mdDialog, serieDialog) {
		$scope.serie = serieDialog;

		$scope.hide = function() {
			$mdDialog.hide();
		};

		$scope.cancel = function() {
			$mdDialog.cancel();
		};

		$scope.answer = function(answer) {
			$mdDialog.hide(answer);
		};
	};
});
