package com.example.lab03.objectServices;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.lab03.object.Usuario;
import com.example.lab03.objectRepository.UsuarioRepository;


@Service
public class UserService {
	
	@Autowired
	private UsuarioRepository usuarioRepository;
	
	public Usuario cadastrar(Usuario usuario) {
		
		List<Usuario> allUsers = usuarioRepository.findAll();
		
		for (Usuario usuario2 : allUsers) {
			if (usuario2.getEmail().equals(usuario.getEmail())) {
				return null;
			}
		}
		return usuarioRepository.save(usuario);
	}
	
	public Usuario logar(Usuario usuario) {
		
		List<Usuario> allUsers = usuarioRepository.findAll();
		
		for (Usuario usuario2 : allUsers) {
			if (usuario2.getEmail().equalsIgnoreCase(usuario.getEmail())) {
				if (usuario2.getPassword().equals(usuario.getPassword())) {
					return usuario2;
				}
			} 
		}
		return null;
	}
}
