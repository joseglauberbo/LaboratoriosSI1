package com.example.lab03.objectController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.lab03.object.Series;
import com.example.lab03.objectServices.SeriesService;

@RestController
@RequestMapping("/serie")
public class SerieController {

	@Autowired
	private SeriesService seriesService;
	
	@RequestMapping(method = RequestMethod.POST, value = "/")
	public ResponseEntity<Series> adicionar(@RequestBody Series serie) {
		Series serieAdicionada = seriesService.adicionaSerie(serie);
		return new ResponseEntity<>(serieAdicionada, HttpStatus.CREATED);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/{serieID}")
	public ResponseEntity<Series> remover(@PathVariable Integer serieID) {
		Series serieRemovida = seriesService.excluirSerie(serieID);
		return new ResponseEntity<>(serieRemovida, HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/{serieID}")
	public ResponseEntity<Series> atualizar(@RequestBody Series serie, @PathVariable Integer serieID) {
		serie.setId(serieID);
		Series serieAtualizada = seriesService.atualizaSerie(serie);
		return new ResponseEntity<>(serieAtualizada, HttpStatus.OK);
	}
	
}
