package si;

import java.lang.reflect.Array;

public class Laboratorio01SI {

	public int retornaMaximo(int[] array) {
		
		int maior = array[0];
		
		for (int i = 1; i < array.length; i++) {
			if (array[i] > maior) {
				maior = array[i];
			}
		}
		return maior;
	}
	
	public int retornaMinimo(int[] array) {
		
		int minimo = array[0];
		
		for (int i = 1; i < array.length; i++) {
			if (array[i] > minimo) {
				minimo = array[i];
			}
		}
		return minimo;
	} 
}
