package testes;

import static org.junit.Assert.*;

import org.junit.Test;

import si.Laboratorio01SI;

public class TesteArray {

	Laboratorio01SI laboratorio = new Laboratorio01SI();
	
	int[] array = {9,8,7,7,5,1,20,1};
	int[] array2 = {10,11,9,7,8,3};
	int[] array3 = {0,0,0,0,0};
	
	@Test
	public void test() {
		assertEquals(laboratorio.retornaMaximo(array), 20);
		assertEquals(laboratorio.retornaMaximo(array2), 11);
		assertEquals(laboratorio.retornaMaximo(array3), 0);
	}

}
